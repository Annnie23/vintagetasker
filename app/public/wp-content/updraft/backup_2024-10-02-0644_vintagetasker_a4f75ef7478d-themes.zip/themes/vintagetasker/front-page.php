<?php
get_header();
?>

<div class="content">

<div class="hero-section">
<?php

if (have_posts()) :
    while (have_posts()) : the_post();

        $herovideo = get_field('herovideo');

        if ($herovideo) {
            echo '<div class="hero-video-wrapper">';
            echo '<video controls autoplay width="100%">';
            echo '<source src="' . esc_url($herovideo['url']) . '" type="' . esc_attr($herovideo['mime_type']) . '">';
            echo 'Your browser does not support the video tag.';
            echo '</video>';
            echo '</div>';
        }

        $herotext = get_field('herotext');
        if ($herotext) {
            echo '<h1 class="hero-title">' . esc_html($herotext) . '</h1>';
        }

    endwhile;
endif;
?>
</div>

<?php
$maerke1 = get_field('maerke1');
$maerke2 = get_field('maerke2');
$maerke3 = get_field('maerke3');
$maerke4 = get_field('maerke4');
$maerke1text = get_field('maerke1text');
$maerke2text = get_field('maerke2text');
$maerke3text = get_field('maerke3text');
$maerke4text = get_field('maerke4text');

echo '<div class="box-section">';
echo '<div class="box-container">';
if ($maerke1) {
    $maerke1img = isset($maerke1['maerke1img']) ? $maerke1['maerke1img'] : null;
    $maerke1link = isset($maerke1['maerke1link']) ? $maerke1['maerke1link'] : null;
    
    echo '<div class="box">';
    if ($maerke1text) {
        echo '<div class="box-title">' . esc_html($maerke1text) . '</div>';
    }
    if ($maerke1img) {
        if ($maerke1link) {
            echo '<a href="' . esc_url($maerke1link) . '" class="box-link">';
        }
        echo '<img src="' . esc_url($maerke1img['url']) . '" alt="' . esc_attr($maerke1img['alt']) . '" class="box-image">';
        if ($maerke1link) {
            echo '</a>';
        }
    }
    echo '</div>';
}

if  ($maerke2) {
    $maerke2img = isset($maerke2['maerke2img']) ? $maerke2['maerke2img'] : null;
    $maerke2link = isset($maerke2['maerke2link']) ? $maerke2['maerke2link'] : null;
    
    echo '<div class="box">';
    if ($maerke2text) {
        echo '<div class="box-title">' . esc_html($maerke2text) . '</div>';
    }
    if ($maerke2img) {
        if ($maerke2link) {
            echo '<a href="' . esc_url($maerke2link) . '" class="box-link">';
        }
        echo '<img src="' . esc_url($maerke2img['url']) . '" alt="' . esc_attr($maerke2img['alt']) . '" class="box-image">';
        if ($maerke2link) {
            echo '</a>';
        }
    }
    echo '</div>';
}

if ($maerke3) {
    $maerke3img = isset($maerke3['maerke3img']) ? $maerke3['maerke3img'] : null;
    $maerke3link = isset($maerke3['maerke3link']) ? $maerke3['maerke3link'] : null;
    
    echo '<div class="box">';
    if ($maerke3text) {
        echo '<div class="box-title">' . esc_html($maerke3text) . '</div>';
    }
    if ($maerke3img) {
        if ($maerke3link) {
            echo '<a href="' . esc_url($maerke3link) . '" class="box-link">';
        }
        echo '<img src="' . esc_url($maerke3img['url']) . '" alt="' . esc_attr($maerke3img['alt']) . '" class="box-image">';
        if ($maerke3link) {
            echo '</a>';
        }
    }
    echo '</div>';
}

if ($maerke4) {
    $maerke4img = isset($maerke4['maerke4img']) ? $maerke4['maerke4img'] : null;
    $maerke4link = isset($maerke4['maerke4link']) ? $maerke4['maerke4link'] : null;
    
    echo '<div class="box">';
    if ($maerke4text) {
        echo '<div class="box-title">' . esc_html($maerke4text) . '</div>';
    }
    if ($maerke4img) {
        if ($maerke4link) {
            echo '<a href="' . esc_url($maerke4link) . '" class="box-link">';
        }
        echo '<img src="' . esc_url($maerke4img['url']) . '" alt="' . esc_attr($maerke4img['alt']) . '" class="box-image">';
        if ($maerke4link) {
            echo '</a>';
        }
    }
    echo '</div>';
}


echo '</div>';
echo '</div>';
?>
